
import './components/style.css';
import Content from './components/Content';
import Footer from './components/Footer';
import Header from './components/Header';


function App() {
  return (
 <div className="combinediv">

<div className="backsideImage">
  <img 
    src={require('./Assets/linecross.png')} 
    alt="backside" 
    className="backside-img"
  />
</div>

<div className="combinesubdiv1">
  <Header />
  <Content />
  <Footer />
</div>
</div>
  );
}
export default App;
