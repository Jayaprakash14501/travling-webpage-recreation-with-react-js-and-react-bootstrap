import React from "react";
import { Container, Card, FormText } from "react-bootstrap";


export default function Content() {
  return (
    <div className="contentcontain">
    <div className="maincard">
      <Container fluid>
        <div className="cardivheading">
          <FormText className="h1">Popular Destinations</FormText>
          <FormText className="p">Vacations to make your experience enjoyable in Indonesia!</FormText>
        </div>
        <div className="cardbox">
            <Card>
              <Card.Img variant="top" src={require('../Assets/rectangle5.png')} />
              <Card.Body>
                <div className="cardlocation">
                  <img src={require('../Assets/Location.png')} alt="Location" />
                  <FormText className="p" >Manggarai Bharat</FormText>
                </div>
                <Card.Title className="title">Flores Road Trip 3D2N</Card.Title>
                <Card.Text className="days">3 Days</Card.Text>
                <Card.Text className="price">
                  Rp 6.705.000 <span>/orang</span>
                </Card.Text>
              </Card.Body>
            </Card>
            <Card>
              <Card.Img variant="top" src={require('../Assets/rectangle2.png')}/>
              <Card.Body>
                <div className="cardlocation">
                  <img src={require('../Assets/Location.png')} alt="Location" />
                  <FormText className="p" >Bogor</FormText>
                </div>
                <Card.Title className="title">Forrester Glamping Co Bogor</Card.Title>
                <Card.Text className="days">1 Day</Card.Text>
                <Card.Text className="price">
                  Rp 1.205.000 <span>/malam</span>
                </Card.Text>
              </Card.Body>
            </Card>

            <Card>
              <Card.Img variant="top" src={require('../Assets/rectangle1.png')}/>
              <Card.Body>
                <div className="cardlocation">
                  <img src={require('../Assets/Location.png')} alt="Location" />
                  <FormText className="p" >Jakarta</FormText>
                </div>
                <Card.Title className="title">
                  Paket Tiket Pesawat<br /> Jakarta Bali
                </Card.Title>
                <Card.Text className="days"></Card.Text>
                <Card.Text className="price">
                  Rp 605.000 <span>/person</span>
                </Card.Text>
              </Card.Body>
            </Card>

            <Card>
              <Card.Img variant="top" src={require('../Assets/rectangle4.png')} />
              <Card.Body>
                <div className="cardlocation">
                  <img src={require('../Assets/Location.png')} alt="Location" />
                  <FormText className="p">Kota Semarang</FormText>
                </div>
                <Card.Title className="title">Desa Wisata Kandri</Card.Title>
                <Card.Text className="days">14 Days</Card.Text>
                <Card.Text className="price">
                  Rp 1.400.000 <span>/person</span>
                </Card.Text>
              </Card.Body>
            </Card>
</div>
      </Container>
    </div>
    <Container fluid className="product">

<div className="productImg">
  <img src={require('../Assets/illustrasi.png')} alt="Illustration" className="img-fluid" />
</div>

<div className="productList">
  <div className="productTitle">
    <FormText className="h1">Why Choose Us</FormText>
    <FormText className="p">Enjoy different experiences in every place you visit and discover new and affordable adventures of course.</FormText>
  </div>
  <div className="productFoot">

        <div className="product1">
          <img src={require('../Assets/Group 84.png')} alt="Flight Ticket" />
          <div className="productCont">
            <FormText className="h1">Flight Ticket</FormText>
            <FormText className="p">Vitae donec pellentesque a aliquam et ultricies auctor.</FormText>
          </div>
        </div>

        <div className="product2">
          <img src={require('../Assets/hotel.png')}  alt="Accommodation" />
          <div className="productCont">
            <FormText className="h1">Accommodation</FormText>
            <FormText className="p">Vitae donec pellentesque a aliquam et ultricies auctor.</FormText>
          </div>
        </div>

        <div className="product3">
          <img src={require('../Assets/Group.png')}  alt="Packaged Tour" />
          <div className="productCont">
            <FormText className="h1">Packaged Tour</FormText>
            <FormText className="p">Vitae donec pellentesque a aliquam et ultricies auctor.</FormText>
          </div>
        </div>

    <div className="anotherProduct">
      Another Product <span><img src={require('../Assets/Vector (1).png')}  alt="Arrow" /></span>
    </div>
  </div>
</div>

</Container>
    </div>
  );
}
