import React from "react";
import { Button, Container, Form ,FormText} from "react-bootstrap";


export default function Footer() {
  return (
    <div className="footer">
    <Container fluid>
      <div className="upperfooter">
            <div className="upperfootertitle">
              <FormText className="h1">Pellentesque suscipit fringilla libero eu.</FormText>
            </div>
            <Button variant="primary" size="md">
              Book Now! <img src={require('../Assets/Down.png')} alt="Down Arrow"/>
            </Button>
      </div>
      <div className="lowerfooter">
            <div className="lowerfooterleft">
              <div className="lowerfooterlefttitle">
                <img src={require('../Assets/Icon.png')} alt="Travling Logo" />
                <FormText className="h1">Travling!</FormText>
              </div>
              <div className="lowerfooterleftpara">
                <FormText className="p">Copyright © 2020 Travling! ltd.</FormText>
                <FormText className="p">All rights reserved</FormText>
              </div>
              <div className="lowerfooterlefticon">
                <div className="lefticon1">
                  <img src={require('../Assets/Path3.png')} alt="Social Icon" />
                </div>
                <div className="lefticon1">
                  <img src={require('../Assets/Path2.png')} alt="Social Icon" />
                </div>
                <div className="lefticon1">
                  <img src={require('../Assets/Path4.png')} alt="Social Icon" />
                </div>
                <div className="lefticon1">
                  <img src={require('../Assets/Path.png')} alt="Social Icon" />
                </div>
              </div>
            </div>
          
            <div className="lowerfooterright">
              <div className="rightcompany">
                <FormText className="h1">Company</FormText>
                <FormText className="p">About us</FormText>
                <FormText className="p">Blog</FormText>
                <FormText className="p">Contact us</FormText>
                <FormText className="p">Pricing</FormText>
                <FormText className="p">Testimonials</FormText>
              </div>
              <div className="rightcompany">
                <FormText className="h1">Support</FormText>
                <FormText className="p">Help Center</FormText>
                <FormText className="p">Terms of service</FormText>
                <FormText className="p">Legal</FormText>
                <FormText className="p">Privacy Policy</FormText>
                <FormText className="p">Status</FormText>
              </div>

              <div className="rightinput">
                <FormText className="h1">Stay up to date</FormText>
                <div className="input-wrapper">
                  <span className="placeholder">
                    <img src={require('../Assets/Vector2.png')} alt="Email Icon" />
                  </span>
                  <Form.Control

                    type="email"
                    className="bg-secondary border-0 custom-placeholder"
                    placeholder="Your email address"
                    variant="white"
                  />
                </div>
                </div>
          </div>
      </div>
    </Container>
    </div>
  );
}
