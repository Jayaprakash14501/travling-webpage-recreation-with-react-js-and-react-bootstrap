import React from 'react';
import { TiThMenu } from "react-icons/ti";
import { Container ,Row,Col,FormText} from 'react-bootstrap';
import Button from 'react-bootstrap/Button';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import 'bootstrap/dist/css/bootstrap.min.css';
import { useState } from 'react';
import Offcanvas from 'react-bootstrap/Offcanvas';
export default function Header(){
    const [show, setShow] = useState(false);
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
    return(
        <div className="Headercontain">

       
     <Navbar className="headDiv">
      <Container fluid>
        <Navbar.Brand className="headTit">Travling!</Navbar.Brand>
          <Nav
            className="navHead"
          >
            <Nav.Link>Product</Nav.Link>
            <Nav.Link>Contact us</Nav.Link>
            <Nav.Link>About us</Nav.Link>
          </Nav>
          <div className="menu">
      <Button variant="primary" onClick={handleShow}>
      < TiThMenu />
      </Button>

      <Offcanvas show={show} onHide={handleClose} backdrop="static" placement="end">
        <Offcanvas.Header closeButton>
          <Offcanvas.Title>Information</Offcanvas.Title>
        </Offcanvas.Header>
        <Offcanvas.Body>
        <Nav
            className="navHead"
          >
            <Nav.Link href="#action1">Product</Nav.Link>
            <Nav.Link href="#action2">Contact</Nav.Link>
            <Nav.Link href="#action2">About us</Nav.Link>
          </Nav>
          <Button variant="orange" size="md">Sign Up</Button>
        </Offcanvas.Body>
      </Offcanvas>
    </div>
          
            <Button variant="orange" size="md" className="signupbut">Sign Up</Button>
      </Container>
    </Navbar>
    <div className="welcomediv">
            <Container fluid>
                <Row>
                    <Col md={6}>
                    <div className="contentdiv">
                        <div className="contentsource">
                            <div className="contenttitle">
                            Start your journey by one click, explore beautiful world!
                            </div>
                            <div className="contentpara">
                            Plan and book your perfect trip with expert advice, travel tips, destination information and inspiration from us!
                            </div>
                        </div>
                        <div className="contentbuttons">
                            <Button variant="dark" size="md">
                                     <div className="button1">
                                        <div className="leftbutton">
                                            <img src={require('../Assets/google-play-png-logo-3789 1.png')}  alt="playstore"/>
                                        </div>
                                        <div className="rightbutton">
                                            <FormText className="line1">Get In On</FormText><FormText  className="line2">Google Play</FormText>
                                        </div>
                                     </div>
                            </Button>
                            <Button variant="dark" size="md">
                                     <div className="button1">
                                        <div className="leftbutton">
                                            <img src={require('../Assets/google-play-png-logo-3789 1 (1).png')}  alt="playstore"/>
                                        </div>
                                        <div className="rightbutton">
                                            <FormText className="line1">Download on the</FormText><FormText className="line2">App Store</FormText>
                                        </div>
                                     </div>
                            </Button>
                        </div>
                    </div>
                    
                    </Col>
                    <Col md={6}>
               
                <div className="contentImage">
                  <img src={require('../Assets/bg.png')} className="background" alt="Background" />
                  <img src={require('../Assets/people.png')} className="overlay2" alt="People" />
                  <div className="overlay1">
                    <img src={require('../Assets/Frame.png')} alt="Overlay 1" />
                  </div>
                  <div className="overlay3">
                    <img src={require('../Assets/Vector.png')} alt="Vector" />
                    <div className="p">Jakarta-Bali</div>
                  </div>
                  <div className="overlay4">
                    <img src={require('../Assets/Rectangle 9.png')} className="img1" alt="rectangle" />
                    <div className="p1">Explore Labuan Bajo</div>
                    <div className="overlay4sub">
                      <img src={require('../Assets/Location.png')} alt="Location" />
                      <div className="p">NTT, Indonesia</div>
                    </div>
                  </div>
                  <div className="overlay5">
                    <img src={require('../Assets/rectangle.png')} className="img1" alt="rectangle" />
                    <div className="p1">Le Pirate Hotel</div>
                    <div className="overlay5sub">
                      <img src={require('../Assets/Location.png')} alt="Location" />
                      <div className="p">Flores, Indonesia</div>
                    </div>
                  </div>
                </div>
              </Col>
                </Row>
            </Container>
        </div>
    </div>
    )
}